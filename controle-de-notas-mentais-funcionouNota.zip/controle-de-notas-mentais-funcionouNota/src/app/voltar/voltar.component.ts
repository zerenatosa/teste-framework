import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-voltar',
  templateUrl: './voltar.component.html',
  styleUrls: ['./voltar.component.css']
})
export class VoltarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
