import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-conteudo-desta-versao',
  templateUrl: './conteudo-desta-versao.component.html',
  styleUrls: ['./conteudo-desta-versao.component.css']
})
export class ConteudoDestaVersaoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
